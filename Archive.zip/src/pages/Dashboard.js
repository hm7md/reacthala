import Header from "../components/Header";
import Leftmenu from "../components/Leftmenu";
import Dashroard from "../components/Dashroad";
import Currency from "../components/Currency";

function Dashboard () {
    return(
        <>
        <Leftmenu/>
        <Header/>
        <Dashroard/>
        <Notification/>
        <Currency/>
        <Color/>
        <Footer/>
        </>
        
    );
} 