import Signup from "../Signup";

function SignupPage(){
    return(
        <Signup/>
    )
}
export default SignupPage;