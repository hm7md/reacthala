import logo from './images/bloom.jpg';
import 'index.css';
function Navigation() {
return (
        <section>
          <div className="topnov">
            
 < img src={logo}/>
              <a href="#saving">saving</a>
              <a href="#creditcards">Credit cards</a>
              <a href="#loans"> loans</a>
              <a href="#my profile">my profile</a>
              <a href="pages/signup.html">sign up</a>
              <a href="#bettermoneyhabits">better money habits</a>
            </div>
            <button>be a partner</button>
          </section>
          );
}
export default Navigation;