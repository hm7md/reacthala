function Header () {
    return(
        
    <section>
    <nav className="nav-bar">
      <img src="https://media.licdn.com/dms/image/C4D0BAQEuRpcll8yu3g/company-logo_200_200/0/1649654487919?e=2147483647&v=beta&t=Nv-cFIJazLFk5yCf5DqjeoEwIiG9PsFpifFRxv9r7og" alt="logo" />

      <div className="topnav">

          <a href="#saving">saving</a>
          <a href="#creditcards">Credit cards</a>
          <a href="#my profile">my profile</a>
          <a href="#bettermoneyhabits">better money habits</a>
          <a href="/index.html">home</a>

    
        </div>
        </nav>
      </section>
   

    );
}

export default Header;