function Infor () {
    return (
        <section>
            <div className="hero-text-container">
        <h1
          >Next generation<br />
          digital banking</h1
        >
        <p
          >Take your financial life online. Your easy bank account<br />
          will be a one-stop-shop for spending,saving,<br />budgeting,investing,
          and much more.</p
        >
        <button>Request Invite</button>
      </div>
      <div className="hero-img-container">

      </div>

        </section>
    );
}
export default Infor;